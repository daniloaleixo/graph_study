#include <stdio.h>
#include <stdlib.h>

FILE *leEntrada(char *nomeArquivo);
char *readLine(FILE *entrada);
void * mallocSafe (size_t n);
